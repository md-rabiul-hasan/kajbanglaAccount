function CheckLogin(userId,password)
{
	alert(userId+'---'+password);
}